import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';

const BASE=process.env.HRAI_BASE||'/vercel/sandbox/hrai';
const SOURCE=`${BASE}/source.m4a`;
const STATUS=`${BASE}/status.json`;
const TRANSCRIPT=`${BASE}/transcript.json`;
const METADATA=`${BASE}/radio-metadata.json`;
const APPROVAL=`${BASE}/transcript-approved.json`;
const ED=`${BASE}/ed-track`;
const AVATAR_R=`${BASE}/avatar-ryoku.png`;
const AVATAR_G=`${BASE}/avatar-guest.png`;
const CAST=`${BASE}/cast.json`;
const REFS=`${BASE}/speaker_refs.json`;
const CHUNKS=`${BASE}/chunks`;
const REF_DIR=`${BASE}/speaker_refs`;
const RENDERS=`${BASE}/renders`;
const THUMB_DIR=`${BASE}/thumbnails`;
const FINAL=`${BASE}/HurricaneRadioAI.mp4`;
const MP3=`${BASE}/HurricaneRadioAI.mp3`;
const WAV=`${BASE}/HurricaneRadioAI.wav`;
const TRANSCRIPT_TXT=`${BASE}/HurricaneRadioAI-transcript.txt`;
const CFG=JSON.parse(await fsp.readFile(process.env.HRAI_CONFIG||'/vercel/sandbox/hrai-config.json','utf8'));
await fsp.mkdir(CHUNKS,{recursive:true});
await fsp.mkdir(REF_DIR,{recursive:true});
await fsp.mkdir(RENDERS,{recursive:true});

async function readJ(f,d){try{return JSON.parse(await fsp.readFile(f,'utf8'))}catch{return d}}
async function writeJ(f,o){const t=f+'.tmp';await fsp.writeFile(t,JSON.stringify(o,null,2));await fsp.rename(t,f)}
async function status(p){const cur=await readJ(STATUS,{jobId:CFG.jobId});await writeJ(STATUS,{...cur,...p,updatedAt:new Date().toISOString()})}
function sleep(ms){return new Promise(r=>setTimeout(r,ms))}
function run(cmd,args,timeout=180000){return new Promise((ok,bad)=>{const p=spawn(cmd,args,{stdio:['ignore','pipe','pipe']});let o='',e='',settled=false;const fail=x=>{if(settled)return;settled=true;clearTimeout(timer);bad(x)},pass=x=>{if(settled)return;settled=true;clearTimeout(timer);ok(x)};const timer=setTimeout(()=>{try{p.kill('SIGKILL')}catch{};fail(new Error(`${cmd} timeout after ${timeout}ms`))},timeout);p.stdout.on('data',d=>o+=d);p.stderr.on('data',d=>e+=d);p.on('error',fail);p.on('close',(c,signal)=>c===0?pass({out:o,err:e}):fail(new Error(`${cmd} ${c==null?`terminated by ${signal||'unknown signal'}`:`exit ${c}`}: ${e.slice(-1400)}`)))})}
async function duration(f){return Number((await run('ffprobe',['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',f])).out.trim())}
async function extractRange(tag,cs,ce,d,ov=1.5){const st=Math.max(0,cs-ov),en=Math.min(d,ce+ov),file=`${CHUNKS}/${tag}.mp3`;if(!fs.existsSync(file))await run('ffmpeg',['-hide_banner','-loglevel','error','-ss',String(st),'-i',SOURCE,'-t',String(en-st),'-vn','-ac','1','-ar','16000','-b:a','64k','-y',file],240000);return{file,st,cs,ce,lcs:cs-st,lce:ce-st}}
async function makeChunk(i,d){const core=180,cs=i*core,ce=Math.min(d,(i+1)*core);return{i,...await extractRange(`c${String(i).padStart(3,'0')}`,cs,ce,d)}}
async function transcribe(file,refs){const b=await fsp.readFile(file);const body={audioBase64:b.toString('base64'),filename:path.basename(file),refs:refs.map(x=>({name:x.stable,dataUrl:x.dataUrl}))};const r=await fetch(CFG.transcribeUrl,{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${CFG.workerToken}`,'x-hrai-job-id':CFG.jobId},body:JSON.stringify(body)});const t=await r.text();if(!r.ok)throw new Error(`TRANSCRIBE_${r.status}: ${t.slice(0,1100)}`);return JSON.parse(t)}
async function makeRefs(data,ch){const picked=new Map();for(const s of data.segments||[]){const raw=String(s.speaker||'A'),st=Number(s.start||0),en=Number(s.end||st),len=en-st;if(!picked.has(raw)&&len>=2.2)picked.set(raw,{raw,st,en});if(picked.size>=4)break}const refs=[];let n=1;for(const item of picked.values()){const stable=`speaker_${n++}`,st=Math.max(0,item.st+.08),len=Math.min(8,Math.max(2.05,item.en-st-.08)),out=`${REF_DIR}/${stable}.wav`;await run('ffmpeg',['-hide_banner','-loglevel','error','-ss',String(st),'-i',ch.file,'-t',String(len),'-ac','1','-ar','16000','-y',out]);refs.push({raw:item.raw,stable,dataUrl:'data:audio/wav;base64,'+(await fsp.readFile(out)).toString('base64')})}await writeJ(REFS,{refs});return refs}
function speakerLabel(apiSpeaker,i,refs){const k=String(apiSpeaker||'A');const stable=refs.find(r=>r.stable===k);if(stable)return stable.stable;if(i===0){const first=refs.find(r=>r.raw===k);if(first)return first.stable}return `unknown_${i}_${k.replace(/[^A-Za-z0-9_-]/g,'_')}`}
async function tailSpeech(ch,data){
  const segs=(data.segments||[]).filter(s=>{const a=Number(s.start||0),b=Number(s.end||a),m=(a+b)/2;return m>=ch.lcs-.001&&m<ch.lce+.001});
  const last=Math.max(ch.lcs,...segs.map(s=>Number(s.end||s.start||0)));
  const gap=ch.lce-last;
  if(gap<=18)return false;
  const start=Math.max(ch.lcs,last-1.5),dur=Math.max(1,ch.lce-start);
  const sil=await run('ffmpeg',['-hide_banner','-ss',String(start),'-i',ch.file,'-t',String(dur),'-af','silencedetect=noise=-38dB:d=4','-f','null','-'],120000).catch(()=>({err:''}));
  const lines=(sil.err||'').split(/\r?\n/),ints=[];let open=null;
  for(const line of lines){let m=line.match(/silence_start:\s*([0-9.]+)/);if(m){open=Number(m[1]);continue}m=line.match(/silence_end:\s*([0-9.]+)/);if(m&&open!=null){ints.push([open,Number(m[1])]);open=null}}
  if(open!=null)ints.push([open,dur]);
  const merged=[];for(const it of ints){if(merged.length&&it[0]-merged[merged.length-1][1]<=0.25)merged[merged.length-1][1]=Math.max(merged[merged.length-1][1],it[1]);else merged.push(it.slice())}
  const tail=merged.length?merged[merged.length-1]:null;
  if(tail&&tail[1]>=dur-.35){const absStart=start+tail[0];const tailLen=tail[1]-tail[0];if(tailLen>=8&&absStart<=last+6)return false}
  let nonsilent=dur;for(const [a,b] of merged)nonsilent-=Math.max(0,Math.min(dur,b)-Math.max(0,a));
  if(nonsilent<5.5)return false;
  const p=await run('ffmpeg',['-hide_banner','-ss',String(start),'-i',ch.file,'-t',String(dur),'-af','volumedetect','-f','null','-'],120000).catch(()=>({err:''}));
  const txt=p.err||'';const max=Number((txt.match(/max_volume:\s*(-?[0-9.]+) dB/)||[])[1]||-99);const mean=Number((txt.match(/mean_volume:\s*(-?[0-9.]+) dB/)||[])[1]||-99);
  return max>-28&&mean>-44;
}
async function transcribeChecked(ch,refs,attempts=3){let lastErr=null;for(let n=1;n<=attempts;n++){try{const data=await transcribe(ch.file,refs);if(!(await tailSpeech(ch,data)))return data;lastErr=new Error('INCOMPLETE_RESULT')}catch(e){lastErr=e}if(n<attempts){await status({phase:`文字起こしを再試行中 (${n}/${attempts-1})`});await sleep(800*n)}}throw lastErr||new Error('INCOMPLETE_RESULT')}
async function transcribeSplit(parent,refs,i,d){const width=60;const all=[];for(let cs=parent.cs,part=0;cs<parent.ce-.001;cs+=width,part++){const ce=Math.min(parent.ce,cs+width);const sub=await extractRange(`c${String(i).padStart(3,'0')}_retry_${part}`,cs,ce,d,4.0);await status({phase:`ブロック ${i+1} を細分化して復旧中`,retryChunk:i+1,retryPart:part+1});let data=null,lastErr=null;for(let n=1;n<=3;n++){try{data=await transcribe(sub.file,refs);break}catch(e){lastErr=e;if(n<3)await sleep(800*n)}}if(!data)throw lastErr||new Error('SPLIT_TRANSCRIBE_FAILED');const offset=sub.st-parent.st;for(const s of data.segments||[]){const a=Number(s.start||0),b=Number(s.end||a),mid=(a+b)/2;if(mid<sub.lcs-.001||mid>=sub.lce+.001)continue;const text=String(s.text||'').trim();if(!text)continue;all.push({...s,start:a+offset,end:b+offset})}}all.sort((a,b)=>Number(a.start||0)-Number(b.start||0)||Number(a.end||0)-Number(b.end||0));return{segments:all,recoveredBySplit:true}}
async function robustTranscribe(ch,refs,i,d){try{return await transcribeChecked(ch,refs,3)}catch{await status({phase:`ブロック ${i+1} を小分けにして復旧中`,retryChunk:i+1});try{return await transcribeSplit(ch,refs,i,d)}catch(e){throw new Error(`TRANSCRIPTION_INCOMPLETE_CHUNK_${i+1}_AFTER_RETRY: ${String(e?.message||e).slice(0,400)}`)}}}

function srtTime(sec){const ms=Math.max(0,Math.round(sec*1000)),h=Math.floor(ms/3600000),m=Math.floor(ms%3600000/60000),s=Math.floor(ms%60000/1000),x=ms%1000;return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')},${String(x).padStart(3,'0')}`}
function assTime(sec){const cs=Math.max(0,Math.round(sec*100)),h=Math.floor(cs/360000),m=Math.floor(cs%360000/6000),s=Math.floor(cs%6000/100),x=cs%100;return `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${String(x).padStart(2,'0')}`}
function assText(s,max=22){const chars=Array.from(cleanSubtitle(s).replace(/[{}\\]/g,'')),lines=[];for(let i=0;i<chars.length;i+=max)lines.push(chars.slice(i,i+max).join(''));return lines.join('\\N')}
function splitCaption(s,max=42){const chars=Array.from(cleanSubtitle(s).replace(/[{}\\]/g,'')),out=[];let rest=chars;while(rest.length>max){let cut=max;for(let i=max-1;i>=Math.floor(max*.58);i--)if(/[、。！？!?…・,.\s]/.test(rest[i])){cut=i+1;break}out.push(rest.slice(0,cut).join('').trim());rest=rest.slice(cut)}if(rest.length)out.push(rest.join('').trim());return out.filter(Boolean)}
function captionSlices(s,start,end){let parts=splitCaption(s),dur=Math.max(.35,end-start),maxParts=Math.max(1,Math.floor(dur/.85));if(parts.length>maxParts){const chars=Array.from(parts.join('')),size=Math.ceil(chars.length/maxParts);parts=[];for(let i=0;i<chars.length;i+=size)parts.push(chars.slice(i,i+size).join(''))}const total=Math.max(1,parts.reduce((n,x)=>n+Array.from(x).length,0));let at=start;return parts.map((text,i)=>{const next=i===parts.length-1?end:Math.min(end,at+dur*Array.from(text).length/total),cue={start:at,end:Math.max(at+.25,next),text};at=next;return cue})}
function assDoc(style,events){return `[Script Info]\nScriptType: v4.00+\nPlayResX: 1280\nPlayResY: 720\nWrapStyle: 2\nScaledBorderAndShadow: yes\n\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n${style}\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n${events.join('\n')}\n`}
function cleanSubtitle(s){return String(s||'').replace(/<[^>]*>/g,'').replace(/[\r\n]+/g,' ').replace(/\s+/g,' ').trim()}
function displaySpeaker(s,cast){const v=String(s||'');if(v==='speaker_1')return 'RYOKU';if(v==='speaker_2')return cleanSubtitle(cast?.guestName||'ゲスト').slice(0,24)||'ゲスト';if(v.startsWith('speaker_'))return `出演者${v.slice(8)}`;return '話者未確認'}
function defaultMetadata(tr,d){const first=cleanSubtitle(tr.segments?.[0]?.text||'今回のトーク').slice(0,34)||'今回のトーク';return{title:'はりけーんradio ミーティング',theme:first,topics:[{start:0,label:first}],model:'fallback',fallback:true,duration:d}}
function normalizeMetadata(m,tr,d){const base=defaultMetadata(tr,d),title=cleanSubtitle(m?.title||base.title).slice(0,40)||base.title,theme=cleanSubtitle(m?.theme||base.theme).slice(0,50)||base.theme,topics=(Array.isArray(m?.topics)?m.topics:[]).slice(0,20).map((x,i)=>({start:Math.max(0,Math.min(d,Number(x?.start)||0)),label:cleanSubtitle(x?.label||`トーク ${i+1}`).slice(0,32)||`トーク ${i+1}`})).sort((a,b)=>a.start-b.start);if(!topics.length)topics.push({start:0,label:theme});if(topics[0].start>1)topics.unshift({start:0,label:theme});return{title,theme,topics,model:String(m?.model||base.model).slice(0,80),fallback:m?!!m.fallback:true,generatedAt:m?.generatedAt||new Date().toISOString()}}
async function ensureMetadata(tr,d){const existing=await readJ(METADATA,null);if(existing?.title&&Array.isArray(existing.topics))return normalizeMetadata(existing,tr,d);await status({stage:'processing',phase:'タイトルと話題をAIで整理中',progress:54,error:null});try{const r=await fetch(CFG.metadataUrl,{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${CFG.workerToken}`,'x-hrai-job-id':CFG.jobId},body:JSON.stringify({duration:d,segments:(tr.segments||[]).map(x=>({start:x.start,end:x.end,speaker:x.speaker,text:x.text}))})}),text=await r.text();if(!r.ok)throw new Error(`METADATA_${r.status}: ${text.slice(0,700)}`);const metadata=normalizeMetadata(JSON.parse(text),tr,d);await writeJ(METADATA,metadata);return metadata}catch(e){const metadata={...defaultMetadata(tr,d),detail:String(e?.message||e).slice(0,500),generatedAt:new Date().toISOString()};await writeJ(METADATA,metadata);return metadata}}
function activeExpr(segs,speaker,start,end){
  const spans=segs.filter(x=>String(x.speaker)===speaker).map(x=>[Math.max(0,Number(x.start||0)-start),Math.min(end-start,Number(x.end||0)-start)]).filter(x=>x[1]>x[0]);
  const merged=[];for(const span of spans){const prev=merged[merged.length-1];if(prev&&span[0]<=prev[1]+.18)prev[1]=Math.max(prev[1],span[1]);else merged.push(span.slice())}
  return merged.length?merged.map(x=>`between(t\\,${x[0].toFixed(3)}\\,${x[1].toFixed(3)})`).join('+'):'0';
}
function radioVisualFilter(srt,speakerSrt,topicSrt,titleFile,guestNameFile,segs,start,end,totalDuration,cast,hasRyokuAvatar,hasGuestAvatar){
  const ryoku=activeExpr(segs,'speaker_1',start,end),guest=activeExpr(segs,'speaker_2',start,end),base=(start/Math.max(1,totalDuration)).toFixed(6),rate=(1/Math.max(1,totalDuration)).toFixed(8);
  const filters=[
    'drawgrid=w=64:h=64:t=1:c=0x456da8@0.13:x=mod(t*15\\,64)-64:y=mod(t*7\\,64)-64',
    "drawbox=x='mod(t*72\\,1540)-130':y=0:w=4:h=720:color=0x6FEFFF@0.10:t=fill",
    "drawbox=x='1280-mod(t*38\\,1540)':y=0:w=2:h=720:color=0xB675FF@0.08:t=fill",
    "drawbox=x=0:y='mod(t*30\\,840)-120':w=1280:h=2:color=0x9CFFD5@0.07:t=fill",
    'drawbox=x=44:y=38:w=1192:h=644:color=0x0A1430@0.96:t=fill','drawbox=x=44:y=38:w=1192:h=644:color=0x274C7C:t=2',
    'drawbox=x=44:y=38:w=1192:h=72:color=0x050B20@0.98:t=fill','drawbox=x=44:y=107:w=1192:h=3:color=0x6FEFFF@0.90:t=fill',
    "drawtext=text='HURRICANE / RADIO':fontcolor=0x6FEFFF:fontsize=18:x=78:y=55","drawtext=text='BROADCAST STUDIO':fontcolor=0x7188B8:fontsize=12:x=80:y=80",
    `drawtext=font='Noto Sans CJK JP':textfile='${titleFile}':expansion=none:fontcolor=0xF7FBFF:fontsize=27:x=(w-text_w)/2:y=57`,
    "drawbox=x=1048:y=54:w=148:h=38:color=0x8F0E33@0.92:t=fill","drawbox=x=1062:y=67:w=10:h=10:color=0xFF5677:t=fill","drawtext=text='ON AIR':fontcolor=0xFFFFFF:fontsize=19:x=1083:y=60",
    'drawbox=x=80:y=138:w=1120:h=306:color=0x050B20@0.72:t=fill','drawbox=x=80:y=138:w=1120:h=306:color=0x1E3D6A@0.80:t=2',
    'drawbox=x=96:y=155:w=292:h=265:color=0x0A2030@0.98:t=fill','drawbox=x=96:y=155:w=292:h=265:color=0x45D69A@0.65:t=2','drawbox=x=96:y=369:w=292:h=51:color=0x0C5D49@0.96:t=fill',
    `drawtext=text='RYOKU':fontcolor=0xFFFFFF:fontsize=${hasRyokuAvatar?25:36}:x=${hasRyokuAvatar?259:176}:y=${hasRyokuAvatar?218:236}`,"drawtext=text='MAIN PERSONALITY':fontcolor=0x9CFFD5:fontsize=12:x=111:y=379","drawtext=text='RYOKU':fontcolor=0xFFFFFF:fontsize=23:x=111:y=394",
    `drawbox=x=86:y=145:w=312:h=285:color=0x65FFBD@0.13:t=fill:enable='${ryoku}'`,`drawbox=x=91:y='150-mod(t*12\\,7)':w=302:h=275:color=0x78FFD0:t=5:enable='${ryoku}'`
  ];
  if(cast.guestEnabled)filters.push(
    'drawbox=x=892:y=155:w=292:h=265:color=0x211331@0.98:t=fill','drawbox=x=892:y=155:w=292:h=265:color=0xB675FF@0.70:t=2','drawbox=x=892:y=369:w=292:h=51:color=0x5A2682@0.96:t=fill',
    `drawtext=font='Noto Sans CJK JP':textfile='${guestNameFile}':expansion=none:fontcolor=0xFFFFFF:fontsize=${hasGuestAvatar?22:31}:x=${hasGuestAvatar?1052:946}:y=${hasGuestAvatar?220:238}`,"drawtext=text='GUEST':fontcolor=0xE3C7FF:fontsize=12:x=907:y=379",`drawtext=font='Noto Sans CJK JP':textfile='${guestNameFile}':expansion=none:fontcolor=0xFFFFFF:fontsize=22:x=907:y=394`,
    `drawbox=x=882:y=145:w=312:h=285:color=0xC995FF@0.13:t=fill:enable='${guest}'`,`drawbox=x=887:y='150-mod(t*12\\,7)':w=302:h=275:color=0xD5ADFF:t=5:enable='${guest}'`
  );
  filters.push(
    'drawbox=x=418:y=172:w=444:h=220:color=0x06122B@0.98:t=fill','drawbox=x=418:y=172:w=444:h=220:color=0x2A7893@0.80:t=2',
    "drawtext=text='LIVE AUDIO / 48 kHz':fontcolor=0x6FEFFF:fontsize=14:x=438:y=188","drawtext=text='VOICE ACTIVITY':fontcolor=0x7188B8:fontsize=11:x=733:y=191",
    'drawbox=x=438:y=220:w=404:h=132:color=0x020817@0.96:t=fill','drawbox=x=438:y=285:w=404:h=1:color=0x6FEFFF@0.28:t=fill',"drawtext=text='● LIVE SIGNAL':fontcolor=0x9CFFD5:fontsize=12:x=438:y=365",
    'drawbox=x=96:y=462:w=1088:h=47:color=0x07102B@0.98:t=fill','drawbox=x=96:y=462:w=6:h=47:color=0x6FEFFF:t=fill','drawbox=x=96:y=508:w=1088:h=2:color=0x274C7C:t=fill',"drawtext=text='NOW PLAYING':fontcolor=0x7188B8:fontsize=11:x=118:y=474",
    `subtitles=filename='${topicSrt}'`,
    'drawbox=x=96:y=536:w=1088:h=99:color=0x050B20@0.96:t=fill','drawbox=x=96:y=536:w=1088:h=99:color=0x274C7C@0.90:t=2','drawbox=x=96:y=536:w=9:h=99:color=0x6FEFFF:t=fill',
    `subtitles=filename='${speakerSrt}'`,
    `subtitles=filename='${srt}'`,
    "drawtext=text='EPISODE PROGRESS':fontcolor=0x7188B8:fontsize=10:x=96:y=648",'drawbox=x=205:y=651:w=979:h=4:color=0x193557@0.95:t=fill',`drawbox=x=205:y=651:w='979*min(1\\,${base}+t*${rate})':h=4:color=0x6FEFFF@0.95:t=fill`
  );
  return{filter:filters.join(','),ryoku,guest};
}
function topicCueFilter(cues){const out=[];for(const c of cues){const e=`between(t\\,${c.start.toFixed(3)}\\,${c.end.toFixed(3)})`,p=`max(0\\,t-${c.start.toFixed(3)})`;out.push(`drawbox=x=0:y=0:w=1280:h=720:color=0x020817@0.90:t=fill:enable='${e}'`,`drawbox=x='-1280+min(1280\\,${p}*1500)':y=188:w=1280:h=344:color=0x071632@0.98:t=fill:enable='${e}'`,`drawbox=x=0:y=188:w=1280:h=4:color=0x6FEFFF:t=fill:enable='${e}'`,`drawbox=x=0:y=528:w=1280:h=4:color=0xB675FF:t=fill:enable='${e}'`,`drawtext=text='SECTION ${String(c.index).padStart(2,'0')}':fontcolor=0x7188B8:fontsize=18:x=(w-text_w)/2:y=240:enable='${e}'`,`drawtext=text='NEXT TOPIC':fontcolor=0x9CFFD5:fontsize=25:x=(w-text_w)/2:y=282:enable='${e}'`,`drawtext=font='Noto Sans CJK JP':textfile='${c.file}':expansion=none:fontcolor=0xFFFFFF:fontsize=44:x=(w-text_w)/2:y=355:enable='${e}'`,`drawbox=x=500:y=438:w=280:h=3:color=0x6FEFFF@0.85:t=fill:enable='${e}'`)}return out.length?out.join(','):'null'}
async function validVideo(file,minDuration,minBytes=100000){if(!fs.existsSync(file))return false;try{const stat=await fsp.stat(file);if(stat.size<minBytes)return false;const d=await duration(file);if(d<Math.max(1,minDuration-1.5))return false;await run('ffmpeg',['-hide_banner','-loglevel','error','-xerror','-i',file,'-map','0:v:0','-map','0:a:0?','-c:v','copy','-bsf:v','h264_mp4toannexb','-c:a','pcm_s16le','-f','null','-'],300000);return true}catch{return false}}
async function commitVideo(tmp,out,minDuration,minBytes=100000){if(!(await validVideo(tmp,minDuration,minBytes))){await fsp.rm(tmp,{force:true});throw new Error(`VIDEO_CACHE_VALIDATION_FAILED_${path.basename(out)}`)}await fsp.rename(tmp,out)}
async function validImage(file,minBytes=5000){if(!fs.existsSync(file))return false;try{const stat=await fsp.stat(file);if(stat.size<minBytes)return false;const meta=(await run('ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=width,height','-of','json',file],30000)).out,v=JSON.parse(meta).streams?.[0];return Number(v?.width)===1280&&Number(v?.height)===720}catch{return false}}
async function validAudio(file,minDuration,minBytes=1000){if(!fs.existsSync(file))return false;try{const stat=await fsp.stat(file);if(stat.size<minBytes)return false;return await duration(file)>=Math.max(1,minDuration-1.5)}catch{return false}}
async function tailMaxVolume(file,seconds=30){try{const r=await run('ffmpeg',['-hide_banner','-loglevel','info','-sseof',String(-Math.max(1,seconds)),'-i',file,'-map','0:a:0','-af','volumedetect','-f','null','-'],120000),m=(r.err||'').match(/max_volume:\s*(-?[0-9.]+) dB/);return m?Number(m[1]):-99}catch{return-99}}
async function finalQA(file,expected,tr,captionCueCount){const raw=(await run('ffprobe',['-v','error','-show_entries','stream=codec_type,codec_name,width,height,sample_rate,channels:format=duration','-of','json',file],60000)).out,info=JSON.parse(raw),video=(info.streams||[]).find(x=>x.codec_type==='video'),audio=(info.streams||[]).find(x=>x.codec_type==='audio'),dur=Number(info.format?.duration||0);if(video?.codec_name!=='h264'||video?.width!==1280||video?.height!==720)throw new Error('FINAL_QA_VIDEO_FORMAT');if(audio?.codec_name!=='aac'||String(audio?.sample_rate)!=='48000'||Number(audio?.channels)!==2)throw new Error('FINAL_QA_AUDIO_FORMAT');if(dur<Math.max(1,expected-1.5))throw new Error('FINAL_QA_DURATION');if(!Array.isArray(tr?.segments)||!tr.segments.length||captionCueCount<tr.segments.filter(x=>cleanSubtitle(x.text)).length)throw new Error('FINAL_QA_CAPTIONS');const sample=Math.min(180,Math.max(10,dur-5)),v=await run('ffmpeg',['-hide_banner','-loglevel','info','-ss','5','-i',file,'-t',String(sample),'-vn','-af','volumedetect','-f','null','-'],240000),txt=v.err||'',max=Number((txt.match(/max_volume:\s*(-?[0-9.]+) dB/)||[])[1]||-99),mean=Number((txt.match(/mean_volume:\s*(-?[0-9.]+) dB/)||[])[1]||-99);if(max<-20||mean<-45)throw new Error(`FINAL_QA_AUDIO_TOO_QUIET: max=${max} mean=${mean}`);return{passed:true,video:'h264-1280x720',audio:'aac-48k-stereo',duration:dur,maxVolumeDb:max,meanVolumeDb:mean,transcriptSegments:tr.segments.length,captionCues:captionCueCount}}
function textTime(sec){const n=Math.max(0,Math.floor(Number(sec)||0)),h=Math.floor(n/3600),m=Math.floor(n%3600/60),s=n%60;return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}
async function renderExports(tr,cast,metadata,vd){
  await status({stage:'exports',phase:'MP3・WAV・文字起こしを書き出し中',progress:98,error:null});
  await run('ffmpeg',['-hide_banner','-loglevel','error','-i',FINAL,'-vn','-c:a','libmp3lame','-b:a','192k','-y',MP3],600000);
  await run('ffmpeg',['-hide_banner','-loglevel','error','-i',FINAL,'-vn','-c:a','pcm_s16le','-ar','48000','-ac','2','-y',WAV],900000);
  if(!(await validAudio(MP3,vd,12000)))throw new Error('MP3_EXPORT_INVALID');
  if(!(await validAudio(WAV,vd,50000)))throw new Error('WAV_EXPORT_INVALID');
  const lines=[`HurricaneRadioAI 文字起こし`,`タイトル：${metadata.title}`,`テーマ：${metadata.theme}`,''];
  for(const x of tr.segments||[]){const text=cleanSubtitle(x.text);if(text)lines.push(`[${textTime(x.start)} - ${textTime(x.end)}] ${displaySpeaker(x.speaker,cast)}：${text}`)}
  await fsp.writeFile(TRANSCRIPT_TXT,'\uFEFF'+lines.join('\n')+'\n','utf8');
  const outputs=[
    {kind:'mp4',name:'HurricaneRadioAI.mp4',mime:'video/mp4',file:FINAL},
    {kind:'mp3',name:'HurricaneRadioAI.mp3',mime:'audio/mpeg',file:MP3},
    {kind:'wav',name:'HurricaneRadioAI.wav',mime:'audio/wav',file:WAV},
    {kind:'transcript',name:'HurricaneRadioAI-transcript.txt',mime:'text/plain; charset=utf-8',file:TRANSCRIPT_TXT}
  ];
  for(const x of outputs){const st=await fsp.stat(x.file);x.bytes=st.size;delete x.file}
  return outputs;
}
async function renderThumbnails(thumbTitleFile,thumbThemeFile,thumbShortFile,d,opDuration){
  await fsp.mkdir(THUMB_DIR,{recursive:true});
  const files=[1,2,3].map(n=>`${THUMB_DIR}/thumbnail-${n}.jpg`);
  await status({stage:'thumbnails',phase:'サムネイル3案を作成中',progress:97,error:null});
  const classic=`drawbox=x=50:y=50:w=1180:h=620:color=0x111d45@0.97:t=fill,drawbox=x=50:y=50:w=1180:h=620:color=0x6FEFFF:t=5,drawtext=text='HurricaneRadioAI':fontcolor=0x6FEFFF:fontsize=38:x=92:y=100,drawtext=text='RADIO TALK':fontcolor=0xF7FBFF:fontsize=34:x=92:y=176,drawtext=font='Noto Sans CJK JP':textfile='${thumbTitleFile}':expansion=none:fontcolor=0xF7FBFF:fontsize=52:x=92:y=286,drawtext=font='Noto Sans CJK JP':textfile='${thumbThemeFile}':expansion=none:fontcolor=0xB9C9EF:fontsize=29:x=94:y=402,drawbox=x=92:y=493:w=330:h=62:color=0x6FEFFF@0.16:t=fill,drawtext=text='ON AIR':fontcolor=0x6FEFFF:fontsize=32:x=190:y=507`;
  await run('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=0x060a1c:s=1280x720','-frames:v','1','-vf',classic,'-q:v','3','-y',files[0]],120000);
  const t2=Math.min(Math.max(opDuration+1,1),Math.max(1,opDuration+d-.2)),visual=`scale=1280:720,drawbox=x=0:y=0:w=1280:h=720:color=0x060a1c@0.18:t=fill,drawbox=x=45:y=470:w=1190:h=205:color=0x07102b@0.88:t=fill,drawbox=x=45:y=470:w=1190:h=205:color=0x6FEFFF:t=4,drawtext=font='Noto Sans CJK JP':textfile='${thumbTitleFile}':expansion=none:fontcolor=0xFFFFFF:fontsize=48:x=78:y=503,drawtext=font='Noto Sans CJK JP':textfile='${thumbThemeFile}':expansion=none:fontcolor=0x6FEFFF:fontsize=27:x=80:y=589`;
  await run('ffmpeg',['-hide_banner','-loglevel','error','-ss',String(t2),'-i',FINAL,'-frames:v','1','-vf',visual,'-q:v','3','-y',files[1]],120000);
  const t3=Math.min(Math.max(opDuration+Math.max(1,d*.65),1),Math.max(1,opDuration+d-.2)),topic=`scale=1280:720,eq=saturation=1.18:contrast=1.08,drawbox=x=0:y=0:w=560:h=720:color=0x07102b@0.90:t=fill,drawbox=x=560:y=0:w=8:h=720:color=0x9CFFD5@0.95:t=fill,drawtext=text='HURRICANE':fontcolor=0x9CFFD5:fontsize=30:x=55:y=80,drawtext=font='Noto Sans CJK JP':textfile='${thumbShortFile}':expansion=none:fontcolor=0xFFFFFF:fontsize=30:x=55:y=190,drawtext=font='Noto Sans CJK JP':textfile='${thumbThemeFile}':expansion=none:fontcolor=0xB9C9EF:fontsize=23:x=57:y=370,drawtext=text='NEW EPISODE':fontcolor=0x9CFFD5:fontsize=27:x=56:y=580`;
  await run('ffmpeg',['-hide_banner','-loglevel','error','-ss',String(t3),'-i',FINAL,'-frames:v','1','-vf',topic,'-q:v','3','-y',files[2]],120000);
  for(const file of files)if(!(await validImage(file)))throw new Error('THUMBNAIL_INVALID');
  return files;
}
async function renderVideo(tr,d){
  const cast=await readJ(CAST,{host:'speaker_1',hostName:'RYOKU',guestEnabled:true,guest:'speaker_2',guestName:'GUEST',avatarFraming:'bust'}),metadata=normalizeMetadata(await readJ(METADATA,null),tr,d),ryokuAvatarFile=fs.existsSync(AVATAR_R)?AVATAR_R:null,hasRyokuAvatar=!!ryokuAvatarFile,hasGuestAvatar=cast.guestEnabled&&fs.existsSync(AVATAR_G),titleFile=`${RENDERS}/title.txt`,themeFile=`${RENDERS}/theme.txt`,guestNameFile=`${RENDERS}/guest-name.txt`,thumbTitleFile=`${RENDERS}/thumb-title.txt`,thumbThemeFile=`${RENDERS}/thumb-theme.txt`,thumbShortFile=`${RENDERS}/thumb-title-short.txt`;
  cast.guestName=cleanSubtitle(cast.guestName||'GUEST').slice(0,24)||'GUEST';cast.avatarFraming=cast.avatarFraming==='full'?'full':'bust';await fsp.writeFile(titleFile,metadata.title,'utf8');await fsp.writeFile(themeFile,metadata.theme,'utf8');await fsp.writeFile(guestNameFile,cast.guestName,'utf8');await fsp.writeFile(thumbTitleFile,metadata.title.slice(0,18)+(metadata.title.length>18?'…':''),'utf8');await fsp.writeFile(thumbThemeFile,metadata.theme.slice(0,28)+(metadata.theme.length>28?'…':''),'utf8');await fsp.writeFile(thumbShortFile,metadata.title.slice(0,14)+(metadata.title.length>14?'…':''),'utf8');
  const opDuration=5,opOut=`${RENDERS}/op_rc14.mp4`,opTmp=`${RENDERS}/op_rc14.partial.mp4`;
  await status({stage:'rendering',phase:'自動OPを作成中',progress:56,error:null});
  if(!(await validVideo(opOut,opDuration,25000))){
    const opFilter=`drawgrid=w=64:h=64:t=1:c=0x456da8@0.18:x=mod(t*28\\,64)-64:y=mod(t*14\\,64)-64,drawbox=x='mod(t*260\\,1660)-190':y=0:w=7:h=720:color=0x6FEFFF@0.18:t=fill,drawbox=x='1280-mod(t*120\\,1540)':y=0:w=3:h=720:color=0xB675FF@0.12:t=fill,drawbox=x=44:y=38:w=1192:h=644:color=0x08132D@0.96:t=fill,drawbox=x=44:y=38:w=1192:h=644:color=0x274C7C:t=2,drawbox=x=44:y=38:w=1192:h=72:color=0x050B20@0.98:t=fill,drawbox=x=44:y=107:w=1192:h=3:color=0x6FEFFF:t=fill,drawtext=text='HURRICANE / RADIO':fontcolor=0x6FEFFF:fontsize=20:x=78:y=59,drawtext=text='ORIGINAL BROADCAST':fontcolor=0x7188B8:fontsize=12:x=994:y=65,drawbox=x=150:y=178:w=980:h=330:color=0x050B20@0.74:t=fill,drawbox=x=150:y=178:w=980:h=330:color=0x2A7893@0.72:t=2,drawtext=text='HURRICANE RADIO NETWORK':fontcolor=0x9CFFD5:fontsize=20:x=(w-text_w)/2:y=210,drawtext=font='Noto Sans CJK JP':textfile='${titleFile}':expansion=none:fontcolor=0xF7FBFF:fontsize=54:x=(w-text_w)/2:y=282,drawbox=x=330:y=358:w=620:h=2:color=0x6FEFFF@0.75:t=fill,drawtext=font='Noto Sans CJK JP':textfile='${themeFile}':expansion=none:fontcolor=0xB9C9EF:fontsize=27:x=(w-text_w)/2:y=390,drawbox=x=510:y=542:w=260:h=48:color=0x8F0E33@0.92:t=fill,drawbox=x=530:y=559:w=10:h=10:color=0xFF5677:t=fill,drawtext=text='NOW ON AIR':fontcolor=0xFFFFFF:fontsize=22:x=558:y=550,fade=t=in:st=0:d=0.65,fade=t=out:st=4.2:d=0.8`;
    await fsp.rm(opTmp,{force:true});await run('ffmpeg',['-hide_banner','-loglevel','error','-threads','1','-filter_threads','1','-f','lavfi','-i','color=c=0x060a1c:s=1280x720:r=24:d=5','-f','lavfi','-i','sine=frequency=523.25:sample_rate=48000:duration=5','-t','5','-vf',opFilter,'-af','volume=0.10,afade=t=in:st=0:d=0.25,afade=t=out:st=3.7:d=1.3','-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','ultrafast','-crf','27','-pix_fmt','yuv420p','-c:a','aac','-ar','48000','-ac','2','-b:a','160k','-movflags','+faststart','-shortest','-y',opTmp],300000);
    await commitVideo(opTmp,opOut,opDuration,25000);
  }
  const width=360,total=Math.ceil(d/width),done=[];let captionCueCount=0;
  for(let i=0;i<total;i++){
    const start=i*width,end=Math.min(d,start+width),len=end-start;
    const out=`${RENDERS}/part_rc142_${String(i).padStart(3,'0')}.mp4`,tmp=`${RENDERS}/part_rc142_${String(i).padStart(3,'0')}.partial.mp4`,srt=`${RENDERS}/part_rc142_${String(i).padStart(3,'0')}.ass`,speakerSrt=`${RENDERS}/speakers_rc142_${String(i).padStart(3,'0')}.ass`,topicSrt=`${RENDERS}/topics_rc142_${String(i).padStart(3,'0')}.ass`;
    const segs=(tr.segments||[]).filter(x=>Number(x.end||0)>start&&Number(x.start||0)<end);
    const captionEvents=[],speakerEvents=[];for(const x of segs){const a=Math.max(0,Number(x.start||0)-start),b=Math.min(len,Math.max(a+.35,Number(x.end||0)-start)),text=cleanSubtitle(x.text);if(!text)continue;for(const cue of captionSlices(text,a,b)){captionEvents.push(`Dialogue: 0,${assTime(cue.start)},${assTime(cue.end)},Caption,,0,0,0,,{\\an4\\pos(285,586)}${assText(cue.text,22)}`);captionCueCount++}speakerEvents.push(`Dialogue: 0,${assTime(a)},${assTime(b)},Speaker,,0,0,0,,{\\an4\\pos(122,586)}${assText(displaySpeaker(x.speaker,cast),12)}`)}
    if(await validVideo(out,len)){done.push(i);continue}
    if(!captionEvents.length)captionEvents.push(`Dialogue: 0,0:00:00.00,${assTime(Math.min(2,len))},Caption,,0,0,0,,{\\an4\\pos(285,586)}HurricaneRadioAI`);
    if(!speakerEvents.length)speakerEvents.push(`Dialogue: 0,0:00:00.00,${assTime(Math.min(2,len))},Speaker,,0,0,0,,{\\an4\\pos(122,586)}HURRICANE RADIO`);
    await fsp.writeFile(srt,assDoc('Style: Caption,Noto Sans CJK JP,25,&H00FFFFFF,&H00FFFFFF,&H00050B20,&H00000000,-1,0,0,0,100,100,0,0,1,1,0,4,0,0,0,1',captionEvents),'utf8');
    await fsp.writeFile(speakerSrt,assDoc('Style: Speaker,Noto Sans CJK JP,17,&H00D5FFFF,&H00D5FFFF,&H00050B20,&H00000000,-1,0,0,0,100,100,0,0,1,1,0,4,0,0,0,1',speakerEvents),'utf8');
    const topicEvents=[],cues=[];for(let q=0;q<metadata.topics.length;q++){const x=metadata.topics[q],next=metadata.topics[q+1],a=Math.max(start,Number(x.start||0)),b=Math.min(end,next?Number(next.start||end):d);if(b<=a)continue;const label=cleanSubtitle(x.label);topicEvents.push(`Dialogue: 0,${assTime(a-start)},${assTime(b-start)},Topic,,0,0,0,,{\\an4\\pos(235,486)}${assText(label,32)}`);const cueStart=Math.max(0,Number(x.start||0)-start);if(cueStart<len&&Number(x.start||0)>=start-.001){const file=`${RENDERS}/topic-cue-rc14-${i}-${q}.txt`;await fsp.writeFile(file,label.slice(0,32),'utf8');cues.push({file,index:q+1,start:cueStart,end:Math.min(len,cueStart+2.2)})}}if(!topicEvents.length)topicEvents.push(`Dialogue: 0,0:00:00.00,${assTime(len)},Topic,,0,0,0,,{\\an4\\pos(235,486)}${assText(metadata.theme,32)}`);await fsp.writeFile(topicSrt,assDoc('Style: Topic,Noto Sans CJK JP,18,&H00FFFFFF,&H00FFFFFF,&H00071122,&H00000000,-1,0,0,0,100,100,0,0,1,1,0,4,0,0,0,1',topicEvents),'utf8');
    await status({stage:'rendering',phase:`動画を分割作成中 (${i+1}/${total})`,renderBlock:i+1,totalRenderBlocks:total,progress:56+Math.floor(34*i/Math.max(total,1)),error:null});
    const visual=radioVisualFilter(srt,speakerSrt,topicSrt,titleFile,guestNameFile,segs,start,end,d,cast,hasRyokuAvatar,hasGuestAvatar),cue=topicCueFilter(cues),audio="[1:a]highpass=f=70,lowpass=f=15000,acompressor=threshold=0.125:ratio=2.4:attack=15:release=180:makeup=1.35,alimiter=limit=0.94,asplit=3[voice][ducksrc][wavein];[2:a]lowpass=f=1800,aecho=0.8:0.65:240|480:0.16|0.10,volume=0.65[bed];[bed][ducksrc]sidechaincompress=threshold=0.025:ratio=10:attack=20:release=700[ducked];[voice][ducked]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95,aresample=48000[aout];[wavein]showwaves=s=380x118:mode=cline:colors=0x6FEFFF@0.96:rate=24,format=rgba[wavev]";
    const args=['-hide_banner','-loglevel','error','-threads','1','-filter_threads','1','-filter_complex_threads','1','-f','lavfi','-i','color=c=0x060a1c:s=1280x720:r=24','-ss',String(start),'-i',SOURCE,'-f','lavfi','-i',`aevalsrc=0.025*(sin(2*PI*110*t)+0.55*sin(2*PI*164.81*t)+0.35*sin(2*PI*220*t)):s=48000:d=${len}`],filters=[`[0:v]${visual.filter}[v0]`];let last='v0',input=3,layer=1;
    if(hasRyokuAvatar){args.push('-loop','1','-framerate','24','-i',ryokuAvatarFile);const next=`v${layer++}`,avatarFilter=cast.avatarFraming==='full'?'scale=168:168,format=rgba':'scale=236:236,crop=168:168:x=(iw-168)/2:y=6,format=rgba';filters.push(`[${input++}:v]${avatarFilter}[aryoku]`,`[${last}][aryoku]overlay=x=158:y='184-if((${visual.ryoku})\\,mod(t*12\\,7)\\,0)':shortest=1[${next}]`);last=next}
    if(hasGuestAvatar){args.push('-loop','1','-framerate','24','-i',AVATAR_G);const next=`v${layer++}`,avatarFilter=cast.avatarFraming==='full'?'scale=168:168,format=rgba':'scale=236:236,crop=168:168:x=(iw-168)/2:y=6,format=rgba';filters.push(`[${input++}:v]${avatarFilter}[aguest]`,`[${last}][aguest]overlay=x=954:y='184-if((${visual.guest})\\,mod(t*12\\,7)\\,0)':shortest=1[${next}]`);last=next}
    filters.push(audio,`[${last}][wavev]overlay=x=450:y=228:eof_action=pass[waveout]`,`[waveout]${cue}[vout]`);args.push('-t',String(len),'-filter_complex',filters.join(';'),'-map','[vout]','-map','[aout]','-c:v','libx264','-preset','ultrafast','-crf','27','-pix_fmt','yuv420p','-c:a','aac','-ar','48000','-ac','2','-b:a','160k','-movflags','+faststart','-shortest','-y',tmp);
    await fsp.rm(tmp,{force:true});await run('ffmpeg',args,900000);
    await commitVideo(tmp,out,len);done.push(i);
    await status({renderedBlocks:done,progress:56+Math.floor(34*(i+1)/Math.max(total,1))});
  }
  const files=[opOut,...done.map(i=>`${RENDERS}/part_rc142_${String(i).padStart(3,'0')}.mp4`)];let expected=opDuration+d,edDuration=0;
  if(fs.existsSync(ED)){
    edDuration=await duration(ED);if(!Number.isFinite(edDuration)||edDuration<1||edDuration>900)throw new Error('ED_DURATION_INVALID');
    const edOut=`${RENDERS}/ed_rc14.mp4`,edTmp=`${RENDERS}/ed_rc14.partial.mp4`;await status({stage:'rendering',phase:'音楽連動ED映像を作成中',progress:92,edDuration});
    const edFilter="drawgrid=w=64:h=64:t=1:c=0x456da8@0.16:x=mod(t*15\\,64)-64:y=mod(t*7\\,64)-64,drawbox=x='mod(t*70\\,1540)-130':y=0:w=4:h=720:color=0x6FEFFF@0.10:t=fill,drawbox=x='1280-mod(t*38\\,1540)':y=0:w=2:h=720:color=0xB675FF@0.08:t=fill,drawbox=x=44:y=38:w=1192:h=644:color=0x08132D@0.96:t=fill,drawbox=x=44:y=38:w=1192:h=644:color=0x274C7C:t=2,drawbox=x=44:y=38:w=1192:h=72:color=0x050B20@0.98:t=fill,drawbox=x=44:y=107:w=1192:h=3:color=0x6FEFFF:t=fill,drawtext=text='HURRICANE / RADIO':fontcolor=0x6FEFFF:fontsize=20:x=78:y=59,drawtext=text='END CREDIT':fontcolor=0x7188B8:fontsize=13:x=1080:y=64,drawtext=text='ENDING':fontcolor=0x6FEFFF:fontsize=56:x=(w-text_w)/2:y=180,drawbox=x=330:y=270:w=620:h=2:color=0x6FEFFF@0.75:t=fill,drawtext=text='Thank you for listening':fontcolor=0xF7FBFF:fontsize=31:x=(w-text_w)/2:y=306,drawtext=text='See you on the next frequency':fontcolor=0xB9C9EF:fontsize=22:x=(w-text_w)/2:y=360,drawbox=x=230:y=430:w=820:h=150:color=0x020817@0.90:t=fill,drawbox=x=230:y=430:w=820:h=150:color=0x2A7893@0.65:t=2,drawtext=text='ENDING TRACK / LIVE WAVEFORM':fontcolor=0x7188B8:fontsize=12:x=250:y=445,fade=t=in:st=0:d=0.8";
    const edComplex=`[0:v]${edFilter}[edbase];[1:a]asplit=2[eda0][edwavein];[edwavein]showwaves=s=760x96:mode=cline:colors=0x6FEFFF@0.94:rate=24,format=rgba[edwave];[edbase][edwave]overlay=x=260:y=472:eof_action=pass[edv];[eda0]aresample=48000[eda]`;
    await fsp.rm(edTmp,{force:true});await run('ffmpeg',['-hide_banner','-loglevel','error','-threads','1','-filter_threads','1','-filter_complex_threads','1','-f','lavfi','-i','color=c=0x060a1c:s=1280x720:r=24','-i',ED,'-t',String(edDuration),'-filter_complex',edComplex,'-map','[edv]','-map','[eda]','-c:v','libx264','-preset','ultrafast','-crf','27','-pix_fmt','yuv420p','-c:a','aac','-ar','48000','-ac','2','-b:a','160k','-movflags','+faststart','-shortest','-y',edTmp],900000);
    await commitVideo(edTmp,edOut,edDuration,25000);files.push(edOut);expected+=edDuration;
  }
  const list=`${RENDERS}/concat.txt`;await fsp.writeFile(list,files.map(file=>`file '${file}'`).join('\n')+'\n');
  await status({stage:'finalizing',phase:'分割動画を結合中',progress:94});
  const finalTmp=`${BASE}/HurricaneRadioAI.partial.mp4`;await fsp.rm(finalTmp,{force:true});await run('ffmpeg',['-hide_banner','-loglevel','error','-fflags','+genpts','-f','concat','-safe','0','-i',list,'-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-af','aresample=async=1:first_pts=0','-avoid_negative_ts','make_zero','-movflags','+faststart','-y',finalTmp],900000);
  await commitVideo(finalTmp,FINAL,expected);if(edDuration>0){const sourceTail=await tailMaxVolume(ED),finalTail=await tailMaxVolume(FINAL);if(sourceTail>-45&&finalTail<-55)throw new Error(`FINAL_ED_AUDIO_MISSING: source=${sourceTail}dB final=${finalTail}dB`)}const stat=await fsp.stat(FINAL),vd=await duration(FINAL),qa=await finalQA(FINAL,expected,tr,captionCueCount),thumbnails=await renderThumbnails(thumbTitleFile,thumbThemeFile,thumbShortFile,d,opDuration),exports=await renderExports(tr,cast,metadata,vd);
  await status({stage:'complete',phase:'投稿用ラジオ動画・サムネイル・書き出しデータが完成しました',progress:100,artifact:{name:'HurricaneRadioAI.mp4',bytes:stat.size,duration:vd,url:'/artifact'},exports,qa,autoFinish:true,voiceMastering:true,smartCaptionCues:true,harmonicBgm:true,thumbnails:thumbnails.map((file,i)=>({number:i+1,name:`HurricaneRadioAI-thumbnail-${i+1}.jpg`,bytes:fs.statSync(file).size})),thumbnailCount:3,renderBlock:total,totalRenderBlocks:total,title:metadata.title,theme:metadata.theme,topicCount:metadata.topics.length,metadataModel:metadata.model,metadataFallback:metadata.fallback,castSelectionIncluded:true,guestEnabled:cast.guestEnabled,ryokuAvatarIncluded:hasRyokuAvatar,guestAvatarIncluded:hasGuestAvatar,opIncluded:true,opDuration,bgmIncluded:true,speakerCardsIncluded:true,edIncluded:edDuration>0,edDuration,totalDuration:vd,error:null});
}

async function main(){
  try{
    if(!fs.existsSync(SOURCE))throw new Error('SOURCE_MISSING');
    const d=await duration(SOURCE), core=180, total=Math.ceil(d/core);
    let tr=await readJ(TRANSCRIPT,{version:2,jobId:CFG.jobId,duration:d,segments:[],completedChunks:[]});
    let refs=(await readJ(REFS,{refs:[]})).refs||[];
    const done=new Set(tr.completedChunks||[]);
    await status({stage:'processing',phase:'実収録を解析中',progress:4,totalChunks:total,duration:d,error:null});
    for(let i=0;i<total;i++){
      if(done.has(i))continue;
      await status({stage:'processing',phase:'文字起こし・話者分離',chunk:i+1,totalChunks:total,progress:5+Math.floor(82*i/Math.max(total,1)),retryChunk:null,retryPart:null,error:null});
      const ch=await makeChunk(i,d);
      const data=await robustTranscribe(ch,refs,i,d);
      if(i===0&&!refs.length)refs=await makeRefs(data,ch);
      const kept=[];
      for(const s of data.segments||[]){const a=Number(s.start||0),b=Number(s.end||a),mid=(a+b)/2;if(mid<ch.lcs-.001||mid>=ch.lce+.001)continue;const text=String(s.text||'').trim();if(!text)continue;kept.push({id:String(s.id||`c${i}_${kept.length}`),start:a+ch.st,end:b+ch.st,text,speaker:speakerLabel(s.speaker,i,refs),speaker_api:String(s.speaker||'A'),chunk:i})}
      tr.segments=tr.segments.filter(x=>Number(x.chunk)!==i).concat(kept).sort((a,b)=>a.start-b.start||a.end-b.end);
      done.add(i);tr.completedChunks=[...done].sort((a,b)=>a-b);tr.refs=refs.map(({raw,stable})=>({raw,stable}));tr.updatedAt=new Date().toISOString();
      await writeJ(TRANSCRIPT,tr);
      await status({lastCompletedChunk:i+1,segments:tr.segments.length,progress:5+Math.floor(82*(i+1)/Math.max(total,1)),retryChunk:null,retryPart:null,error:null});
    }
    const lastEnd=Math.max(0,...tr.segments.map(s=>Number(s.end||0)));
    if(d-lastEnd>25){const p=await run('ffmpeg',['-hide_banner','-ss',String(Math.max(lastEnd,d-45)),'-i',SOURCE,'-af','volumedetect','-f','null','-'],120000).catch(()=>({err:''}));const max=Number(((p.err||'').match(/max_volume:\s*(-?[0-9.]+) dB/)||[])[1]||-99);if(max>-34)throw new Error('TRANSCRIPTION_TAIL_INCOMPLETE')}
    const metadata=await ensureMetadata(tr,d);
    if(!fs.existsSync(APPROVAL)){
      await status({stage:'transcript_review',phase:'タイトル・話題・文字起こしを確認してください',progress:55,chunk:total,totalChunks:total,segments:tr.segments.length,duration:d,title:metadata.title,topicCount:metadata.topics.length,error:null,retryChunk:null,retryPart:null});
      return;
    }
    await status({stage:'rendering',phase:'確認済み字幕から動画作成を開始',progress:56,chunk:total,totalChunks:total,segments:tr.segments.length,duration:d,error:null,retryChunk:null,retryPart:null});
    await renderVideo(tr,d);
  }catch(e){const error=String(e?.message||e).slice(0,1500),recoverable=/ffmpeg (?:terminated by|timeout)/i.test(error);await status({stage:recoverable?'recoverable':'failed',phase:recoverable?'映像処理が一時停止しました。自動再開します':'安全停止',error})}
}
await main();
