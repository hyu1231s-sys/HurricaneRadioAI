import crypto from 'node:crypto';
import { Sandbox } from '@vercel/sandbox';

const SNAP='snap_mW7maB1otMUcQXf9G59Y4z4dO6Ip';
const HASH='73b792e9085cacf010cb0f1f903f54600ef38d340b9a53c08eaaa345a9e798fd';
const FALLBACK_ORIGIN='https://hurricane-radio-ai.vercel.app';
const BASE='/vercel/sandbox/hrai';
const SOURCE=`${BASE}/source.m4a`;
const PART=`${BASE}/source.m4a.part`;
const STATUS=`${BASE}/status.json`;
const TRANSCRIPT=`${BASE}/transcript.json`;
const METADATA=`${BASE}/radio-metadata.json`;
const APPROVAL=`${BASE}/transcript-approved.json`;
const ED=`${BASE}/ed-track`;
const EDPART=`${BASE}/ed-track.part`;
const AVATAR_R=`${BASE}/avatar-ryoku.png`;
const AVATAR_G=`${BASE}/avatar-guest.png`;
const THUMB_DIR=`${BASE}/thumbnails`;
const CAST=`${BASE}/cast.json`;
const FINAL=`${BASE}/HurricaneRadioAI.mp4`;
const MP3=`${BASE}/HurricaneRadioAI.mp3`;
const WAV=`${BASE}/HurricaneRadioAI.wav`;
const TRANSCRIPT_TXT=`${BASE}/HurricaneRadioAI-transcript.txt`;
const origin=req=>{const host=String(req.headers['x-forwarded-host']||req.headers.host||'');return host?`https://${host}`:FALLBACK_ORIGIN};
const valid=s=>/^job_[a-f0-9]{24}$/.test(String(s||''));
const hash=s=>crypto.createHash('sha256').update(String(s||'')).digest('hex');
const ok=s=>hash(s)===HASH;
const token=j=>crypto.createHmac('sha256',process.env.OPENAI_API_KEY||'').update(`hrai-worker:${j}`).digest('base64url');
const name=j=>`hrai-${j.slice(4)}`;

async function body(req){
  if(req.body&&typeof req.body==='object')return req.body;
  if(typeof req.body==='string')return JSON.parse(req.body||'{}');
  let s='';for await(const c of req)s+=c;return s?JSON.parse(s):{};
}
async function requestBody(req,res){try{return await body(req)}catch{res.status(400).json({error:'invalid_json'});return null}}
function jobAuth(b){const j=String(b?.jobId||''),t=String(b?.workerToken||'');return valid(j)&&t===token(j)?j:null}
function within(p,ms,label){let timer;const timeout=new Promise((_,bad)=>{timer=setTimeout(()=>bad(new Error(label)),ms)});return Promise.race([Promise.resolve(p).finally(()=>clearTimeout(timer)),timeout])}
async function mk(n,persistent=true,timeout=2640000){return Sandbox.create({name:n,source:{type:'snapshot',snapshotId:SNAP},ports:[],timeout,resources:{vcpus:2},persistent})}
async function getOrCreate(j,create=true){try{return await Sandbox.get({name:name(j)})}catch(e){if(!create||e?.response?.status!==404)throw e;return mk(name(j))}}
async function stdout(sb,cmd,args){const r=await sb.runCommand(cmd,args);return await r.stdout()}
async function pipelineAlive(sb){return(await stdout(sb,'bash',['-lc',"pgrep -f '[n]ode /vercel/sandbox/hrai-pipeline\\.mjs' >/dev/null && printf yes || printf no"])).trim()==='yes'}
function processingConflict(res){return res.status(409).json({error:'job_already_processing',detail:'既存の処理を保護するため設定変更を停止しました',retryable:true})}
async function prep(sb,j,t,o){
  await sb.runCommand('bash',['-lc',"pkill -f '[n]ode .*/hrai-pipeline\\.mjs' >/dev/null 2>&1 || true; pkill -f '[n]ode .*/worker-server\\.mjs' >/dev/null 2>&1 || true; rm -f /vercel/sandbox/hrai/pipeline.pid; mkdir -p /vercel/sandbox/hrai"]);
  await sb.writeFiles([{path:'/vercel/sandbox/hrai-config.json',content:Buffer.from(JSON.stringify({jobId:j,workerToken:t,transcribeUrl:`${o}/api/transcribe-chunk`,metadataUrl:`${o}/api/generate-metadata`}))}]);
  await sb.runCommand('curl',['-fsSL',`${o}/worker/hrai-pipeline.mjs`,'-o','/vercel/sandbox/hrai-pipeline.mjs']);
}
async function runPipeline(sb){
  await sb.runCommand('bash',['-lc',"if [ -f /vercel/sandbox/hrai/pipeline.pid ] && kill -0 $(cat /vercel/sandbox/hrai/pipeline.pid) 2>/dev/null; then exit 0; fi; rm -f /vercel/sandbox/hrai/pipeline.pid"]);
  await sb.runCommand({cmd:'node',args:['/vercel/sandbox/hrai-pipeline.mjs'],detached:true});
}
async function sourceMeta(sb){
  const out=await stdout(sb,'bash',['-lc',`if [ ! -f ${SOURCE} ]; then printf '{"exists":false}'; exit 0; fi; b=$(stat -c %s ${SOURCE}); d=$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 ${SOURCE} 2>/dev/null || printf 0); printf '{"exists":true,"bytes":%s,"duration":%s}' "$b" "$d"`]);
  return JSON.parse(out||'{"exists":false}');
}
async function start(req,res){
  const b=await requestBody(req,res);if(!b)return;
  if(!ok(b.access))return res.status(401).json({error:'owner_access_required'});
  if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'openai_not_configured'});
  const resume=valid(b.jobId),j=resume?String(b.jobId):`job_${crypto.randomBytes(12).toString('hex')}`,t=token(j);
  try{let sb,created=false;if(resume){try{sb=await within(getOrCreate(j,false),20000,'SANDBOX_CONNECT_TIMEOUT')}catch(e){if(e?.response?.status!==404)throw e;sb=await mk(name(j));created=true}}else{sb=await mk(name(j));created=true}if(created)await prep(sb,j,t,origin(req));return res.status(200).json({ok:true,jobId:j,workerToken:t,resumable:true,reconnected:resume&&!created,created,transport:'vercel-api-bridge'})}
  catch(e){console.error('start-job failed',e);const quota=e?.response?.status===402||e?.json?.error?.code==='payment_required';return res.status(quota?503:500).json({ok:false,error:quota?'sandbox_quota_exceeded':'worker_start_failed',detail:quota?'Vercel Sandboxの保存容量上限です。既存jobは再開できますが、新規job作成には不要Snapshotの整理が必要です。':String(e?.message||e).slice(0,700)})}
}
async function sourceInfo(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});
  try{return res.status(200).json(await sourceMeta(await getOrCreate(j,false)))}catch(e){if(e?.response?.status===404)return res.status(200).json({exists:false});return res.status(500).json({error:'source_info_failed',detail:String(e?.message||e).slice(0,500)})}
}
async function status(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});
  try{const data=await within((async()=>{const sb=await getOrCreate(j,false),out=await stdout(sb,'bash',['-lc',`if [ -f ${STATUS} ]; then cat ${STATUS}; else printf '{"stage":"waiting","phase":"音声を待っています","progress":1}'; fi`]);let state=JSON.parse(out),recoverable=state.stage==='recoverable'||(state.stage==='failed'&&/^ffmpeg null:/i.test(String(state.error||'')));if(recoverable&&!(await pipelineAlive(sb))){const attempts=Number(state.ffmpegRestarts||0);if(attempts<3){state={...state,stage:'resuming',phase:`映像処理を自動再開中 (${attempts+1}/3)`,error:null,ffmpegRestarts:attempts+1,updatedAt:new Date().toISOString()};await sb.writeFiles([{path:STATUS,content:Buffer.from(JSON.stringify(state,null,2))}]);await prep(sb,j,token(j),origin(req));await runPipeline(sb)}else state={...state,stage:'failed',phase:'映像処理の自動再開上限に達したため安全停止',error:`FFMPEG_SIGNAL_RETRY_EXHAUSTED: ${String(state.error||'process terminated').slice(0,500)}`};}return state})(),20000,'SANDBOX_STATUS_TIMEOUT');return res.status(200).json(data)}
  catch(e){const detail=String(e?.message||e).slice(0,500),missing=e?.response?.status===404;console.error('[job-status] failed',{jobId:j,detail,missing});return res.status(missing?410:detail==='SANDBOX_STATUS_TIMEOUT'?503:500).json({error:missing?'job_not_found':detail==='SANDBOX_STATUS_TIMEOUT'?'status_temporarily_unavailable':'status_failed',detail,retryable:!missing})}
}
async function resume(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});
  try{const result=await within((async()=>{const sb=await getOrCreate(j,false),m=await sourceMeta(sb);if(!m.exists)return{missing:true};let state={};try{state=JSON.parse(await stdout(sb,'cat',[STATUS]))}catch{}const complete=state.stage==='complete'&&(await stdout(sb,'bash',['-lc',`[ -f ${FINAL} ] && printf yes || printf no`])).trim()==='yes',review=state.stage==='transcript_review';if(complete||review)return{missing:false,alive:false,complete,review};const alive=await pipelineAlive(sb);if(!alive){await sb.writeFiles([{path:STATUS,content:Buffer.from(JSON.stringify({...state,jobId:j,stage:'resuming',phase:'保存済みデータから安全に再開中',progress:Number(state.progress||4),error:null,updatedAt:new Date().toISOString()}))}]);await prep(sb,j,token(j),origin(req));await runPipeline(sb)}return{missing:false,alive,complete:false,review:false}})(),45000,'SANDBOX_RESUME_TIMEOUT');if(result.missing)return res.status(409).json({error:'source_missing'});return res.status(202).json({ok:true,resumed:true,alreadyDone:result.complete,reviewReady:result.review,alreadyRunning:result.alive,restarted:!result.alive&&!result.complete&&!result.review})}
  catch(e){const detail=String(e?.message||e).slice(0,700);console.error('[resume-job] failed',{jobId:j,detail});return res.status(detail==='SANDBOX_RESUME_TIMEOUT'?503:500).json({error:detail==='SANDBOX_RESUME_TIMEOUT'?'resume_temporarily_unavailable':'resume_failed',detail,retryable:true})}
}
async function uploadInit(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});
  const bytes=Number(b.bytes||0);if(!Number.isSafeInteger(bytes)||bytes<512||bytes>1500000000)return res.status(400).json({error:'invalid_source_size'});
  try{const sb=await getOrCreate(j,false);if(await pipelineAlive(sb))return processingConflict(res);await sb.runCommand('bash',['-lc',`rm -f ${PART} ${SOURCE} ${TRANSCRIPT} ${METADATA} ${APPROVAL} ${ED} ${EDPART} ${BASE}/speaker_refs.json ${BASE}/pipeline.pid ${FINAL} ${MP3} ${WAV} ${TRANSCRIPT_TXT}; rm -rf ${BASE}/chunks ${BASE}/speaker_refs ${BASE}/renders; mkdir -p ${BASE}`]);await sb.writeFiles([{path:STATUS,content:Buffer.from(JSON.stringify({jobId:j,stage:'uploading',phase:'音声をアップロード中',progress:2,expectedBytes:bytes,receivedBytes:0,updatedAt:new Date().toISOString()}))}]);return res.status(200).json({ok:true})}
  catch(e){return res.status(500).json({error:'upload_init_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function uploadChunk(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});
  const index=Number(b.index),a=Buffer.from(String(b.audioBase64||''),'base64');if(!Number.isInteger(index)||index<0||index>2000||!a.length||a.length>2100000)return res.status(400).json({error:'invalid_upload_chunk'});
  const tmp=`${BASE}/upload-${String(index).padStart(5,'0')}.part`;
  try{const sb=await getOrCreate(j,false);await sb.writeFiles([{path:tmp,content:a}]);await sb.runCommand('bash',['-lc',`cat ${tmp} >> ${PART} && rm -f ${tmp}`]);const received=Number((await stdout(sb,'stat',['-c','%s',PART])).trim());return res.status(200).json({ok:true,receivedBytes:received})}
  catch(e){return res.status(500).json({error:'upload_chunk_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function uploadComplete(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const expected=Number(b.bytes||0);
  try{const sb=await getOrCreate(j,false),actual=Number((await stdout(sb,'stat',['-c','%s',PART])).trim());if(!Number.isSafeInteger(expected)||actual!==expected)return res.status(409).json({error:'upload_size_mismatch',expected,actual});await sb.runCommand('ffprobe',['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',PART]);await sb.runCommand('mv',['-f',PART,SOURCE]);await sb.writeFiles([{path:STATUS,content:Buffer.from(JSON.stringify({jobId:j,stage:'source_ready',phase:'音声を受け取りました',progress:7,sourceBytes:actual,updatedAt:new Date().toISOString()}))}]);return res.status(202).json({ok:true,bytes:actual,sourceReady:true})}
  catch(e){return res.status(500).json({error:'upload_complete_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function edUploadInit(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const bytes=Number(b.bytes||0);if(!Number.isSafeInteger(bytes)||bytes<512||bytes>300000000)return res.status(400).json({error:'invalid_ed_size'});
  try{const sb=await getOrCreate(j,false);if(await pipelineAlive(sb))return processingConflict(res);await sb.runCommand('bash',['-lc',`rm -f ${EDPART} ${ED} ${FINAL}; rm -rf ${BASE}/renders`]);return res.status(200).json({ok:true})}catch(e){return res.status(500).json({error:'ed_upload_init_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function edUploadChunk(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const index=Number(b.index),a=Buffer.from(String(b.audioBase64||''),'base64');if(!Number.isInteger(index)||index<0||index>500||!a.length||a.length>2100000)return res.status(400).json({error:'invalid_ed_chunk'});const tmp=`${BASE}/ed-upload-${String(index).padStart(5,'0')}.part`;
  try{const sb=await getOrCreate(j,false);await sb.writeFiles([{path:tmp,content:a}]);await sb.runCommand('bash',['-lc',`cat ${tmp} >> ${EDPART} && rm -f ${tmp}`]);const received=Number((await stdout(sb,'stat',['-c','%s',EDPART])).trim());return res.status(200).json({ok:true,receivedBytes:received})}catch(e){return res.status(500).json({error:'ed_upload_chunk_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function edUploadComplete(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const expected=Number(b.bytes||0);
  try{const sb=await getOrCreate(j,false),actual=Number((await stdout(sb,'stat',['-c','%s',EDPART])).trim());if(!Number.isSafeInteger(expected)||actual!==expected)return res.status(409).json({error:'ed_size_mismatch',expected,actual});const duration=Number((await stdout(sb,'ffprobe',['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',EDPART])).trim());if(!Number.isFinite(duration)||duration<1||duration>900)return res.status(400).json({error:'invalid_ed_duration',duration});await sb.runCommand('mv',['-f',EDPART,ED]);return res.status(200).json({ok:true,bytes:actual,duration})}catch(e){return res.status(500).json({error:'ed_upload_complete_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function edClear(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});try{const sb=await getOrCreate(j,false);if(await pipelineAlive(sb))return processingConflict(res);await sb.runCommand('bash',['-lc',`rm -f ${EDPART} ${ED}`]);return res.status(200).json({ok:true,ed:false})}catch(e){return res.status(500).json({error:'ed_clear_failed',detail:String(e?.message||e).slice(0,500)})}
}
function avatarPaths(role){if(role==='ryoku')return{file:AVATAR_R,part:`${BASE}/avatar-ryoku.part`};if(role==='guest')return{file:AVATAR_G,part:`${BASE}/avatar-guest.part`};return null}
async function avatarUploadInit(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const p=avatarPaths(String(b.role||'')),bytes=Number(b.bytes||0);if(!p)return res.status(400).json({error:'invalid_avatar_role'});if(!Number.isSafeInteger(bytes)||bytes<128||bytes>20000000)return res.status(400).json({error:'invalid_avatar_size'});
  try{const sb=await getOrCreate(j,false);if(await pipelineAlive(sb))return processingConflict(res);await sb.runCommand('bash',['-lc',`rm -f ${p.part} ${p.file} ${FINAL}; rm -rf ${BASE}/renders`]);return res.status(200).json({ok:true,role:b.role})}catch(e){return res.status(500).json({error:'avatar_upload_init_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function avatarUploadChunk(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const p=avatarPaths(String(b.role||'')),index=Number(b.index),a=Buffer.from(String(b.audioBase64||''),'base64');if(!p)return res.status(400).json({error:'invalid_avatar_role'});if(!Number.isInteger(index)||index<0||index>50||!a.length||a.length>1500000)return res.status(400).json({error:'invalid_avatar_chunk'});const tmp=`${BASE}/avatar-${b.role}-${String(index).padStart(3,'0')}.part`;
  try{const sb=await getOrCreate(j,false);await sb.writeFiles([{path:tmp,content:a}]);await sb.runCommand('bash',['-lc',`cat ${tmp} >> ${p.part} && rm -f ${tmp}`]);const received=Number((await stdout(sb,'stat',['-c','%s',p.part])).trim());return res.status(200).json({ok:true,role:b.role,receivedBytes:received})}catch(e){return res.status(500).json({error:'avatar_upload_chunk_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function avatarUploadComplete(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const p=avatarPaths(String(b.role||'')),expected=Number(b.bytes||0);if(!p)return res.status(400).json({error:'invalid_avatar_role'});
  try{const sb=await getOrCreate(j,false),actual=Number((await stdout(sb,'stat',['-c','%s',p.part])).trim());if(!Number.isSafeInteger(expected)||actual!==expected)return res.status(409).json({error:'avatar_size_mismatch',expected,actual});const meta=JSON.parse(await stdout(sb,'ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=codec_name,width,height','-of','json',p.part])),v=meta.streams?.[0];if(!v||Number(v.width)<32||Number(v.height)<32||Number(v.width)>8192||Number(v.height)>8192)return res.status(400).json({error:'invalid_avatar_image'});await sb.runCommand('ffmpeg',['-hide_banner','-loglevel','error','-i',p.part,'-vf','scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black@0','-frames:v','1','-y',p.file]);await sb.runCommand('bash',['-lc',`rm -f ${p.part}`]);return res.status(200).json({ok:true,role:b.role,bytes:actual,width:512,height:512})}catch(e){return res.status(500).json({error:'avatar_upload_complete_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function avatarClear(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const p=avatarPaths(String(b.role||''));if(!p)return res.status(400).json({error:'invalid_avatar_role'});try{const sb=await getOrCreate(j,false);if(await pipelineAlive(sb))return processingConflict(res);await sb.runCommand('bash',['-lc',`rm -f ${p.part} ${p.file} ${FINAL}; rm -rf ${BASE}/renders`]);return res.status(200).json({ok:true,role:b.role,avatar:false})}catch(e){return res.status(500).json({error:'avatar_clear_failed',detail:String(e?.message||e).slice(0,500)})}
}
async function castSave(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const guestName=String(b.guestName||'GUEST').replace(/[\r\n]+/g,' ').replace(/\s+/g,' ').trim().slice(0,24)||'GUEST',avatarFraming=b.avatarFraming==='full'?'full':'bust',cast={host:'speaker_1',hostName:'RYOKU',guestEnabled:b.guestEnabled!==false,guest:'speaker_2',guestName,avatarFraming,updatedAt:new Date().toISOString()};try{const sb=await getOrCreate(j,false);let old={};try{old=JSON.parse(await stdout(sb,'cat',[CAST]))}catch{}const unchanged=old.host===cast.host&&old.hostName===cast.hostName&&old.guestEnabled===cast.guestEnabled&&old.guest===cast.guest&&old.guestName===cast.guestName&&(old.avatarFraming||'bust')===cast.avatarFraming;if(await pipelineAlive(sb)){if(unchanged)return res.status(200).json({ok:true,cast:old,unchanged:true,protectedActiveRender:true});return processingConflict(res)}await sb.writeFiles([{path:CAST,content:Buffer.from(JSON.stringify(cast,null,2))}]);await sb.runCommand('bash',['-lc',`rm -f ${FINAL}; rm -rf ${BASE}/renders`]);return res.status(200).json({ok:true,cast,unchanged})}catch(e){return res.status(500).json({error:'cast_save_failed',detail:String(e?.message||e).slice(0,500)})}
}
async function artifactInfo(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});
  try{const sb=await getOrCreate(j,false),bytes=Number((await stdout(sb,'stat',['-c','%s',FINAL])).trim());return res.status(200).json({ok:true,name:'HurricaneRadioAI.mp4',bytes,chunkSize:1500000,totalChunks:Math.ceil(bytes/1500000)})}
  catch(e){return res.status(404).json({error:'artifact_not_found',detail:String(e?.message||e).slice(0,300)})}
}
async function artifactChunk(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const index=Number(b.index),size=1500000;if(!Number.isInteger(index)||index<0||index>10000)return res.status(400).json({error:'invalid_artifact_chunk'});
  try{const sb=await getOrCreate(j,false),data=(await stdout(sb,'bash',['-lc',`dd if=${FINAL} bs=${size} skip=${index} count=1 status=none | base64 -w0`])).trim();return res.status(200).json({ok:true,index,audioBase64:data})}
  catch(e){return res.status(404).json({error:'artifact_chunk_not_found',detail:String(e?.message||e).slice(0,300)})}
}
function exportSpec(kind){return({mp4:{file:FINAL,name:'HurricaneRadioAI.mp4',mime:'video/mp4'},mp3:{file:MP3,name:'HurricaneRadioAI.mp3',mime:'audio/mpeg'},wav:{file:WAV,name:'HurricaneRadioAI.wav',mime:'audio/wav'},transcript:{file:TRANSCRIPT_TXT,name:'HurricaneRadioAI-transcript.txt',mime:'text/plain; charset=utf-8'}})[String(kind||'')]||null}
async function exportInfo(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b),spec=exportSpec(b.kind);if(!j)return res.status(401).json({error:'unauthorized'});if(!spec)return res.status(400).json({error:'invalid_export_kind'});
  try{const sb=await getOrCreate(j,false),bytes=Number((await stdout(sb,'stat',['-c','%s',spec.file])).trim()),chunkSize=1500000;if(!Number.isSafeInteger(bytes)||bytes<1)throw new Error('EXPORT_EMPTY');return res.status(200).json({ok:true,kind:b.kind,name:spec.name,mime:spec.mime,bytes,chunkSize,totalChunks:Math.ceil(bytes/chunkSize)})}
  catch(e){return res.status(404).json({error:'export_not_found',detail:String(e?.message||e).slice(0,300)})}
}
async function exportChunk(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b),spec=exportSpec(b.kind),index=Number(b.index),size=1500000;if(!j)return res.status(401).json({error:'unauthorized'});if(!spec)return res.status(400).json({error:'invalid_export_kind'});if(!Number.isInteger(index)||index<0||index>10000)return res.status(400).json({error:'invalid_export_chunk'});
  try{const sb=await getOrCreate(j,false),data=(await stdout(sb,'bash',['-lc',`dd if=${spec.file} bs=${size} skip=${index} count=1 status=none | base64 -w0`])).trim();if(!data)throw new Error('EXPORT_CHUNK_EMPTY');return res.status(200).json({ok:true,kind:b.kind,index,dataBase64:data})}
  catch(e){return res.status(404).json({error:'export_chunk_not_found',detail:String(e?.message||e).slice(0,300)})}
}
async function thumbnailGet(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});const number=Number(b.number);if(!Number.isInteger(number)||number<1||number>3)return res.status(400).json({error:'invalid_thumbnail_number'});
  const file=`${THUMB_DIR}/thumbnail-${number}.jpg`;
  try{const sb=await getOrCreate(j,false),bytes=Number((await stdout(sb,'stat',['-c','%s',file])).trim());if(!Number.isSafeInteger(bytes)||bytes<1000||bytes>3000000)throw new Error('THUMBNAIL_SIZE_INVALID');const imageBase64=(await stdout(sb,'base64',['-w','0',file])).trim();return res.status(200).json({ok:true,number,name:`HurricaneRadioAI-thumbnail-${number}.jpg`,bytes,mime:'image/jpeg',imageBase64})}
  catch(e){return res.status(404).json({error:'thumbnail_not_found',detail:String(e?.message||e).slice(0,300)})}
}
async function transcriptGet(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});
  try{const sb=await getOrCreate(j,false),out=await stdout(sb,'cat',[TRANSCRIPT]),tr=JSON.parse(out);if(!Array.isArray(tr.segments))throw new Error('TRANSCRIPT_INVALID');let metadata=null;try{metadata=JSON.parse(await stdout(sb,'cat',[METADATA]))}catch{}return res.status(200).json({ok:true,version:tr.version||2,duration:Number(tr.duration||0),segments:tr.segments,completedChunks:tr.completedChunks||[],refs:tr.refs||[],editedAt:tr.editedAt||null,metadata})}
  catch(e){return res.status(404).json({error:'transcript_not_found',detail:String(e?.message||e).slice(0,400)})}
}
function cleanSegment(s,i){
  const start=Number(s?.start),end=Number(s?.end),text=String(s?.text||'').replace(/[\r\n]+/g,' ').replace(/\s+/g,' ').trim().slice(0,1200),raw=String(s?.speaker||'unknown');
  if(!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<start||end-start>3600)throw new Error(`INVALID_SEGMENT_${i+1}`);
  const speaker=/^speaker_[1-9][0-9]*$/.test(raw)?raw:'unknown';
  return{id:String(s?.id||`edited_${i}`).slice(0,160),start,end,text,speaker,speaker_api:String(s?.speaker_api||'edited').slice(0,80),chunk:Number.isInteger(Number(s?.chunk))?Number(s.chunk):0};
}
function cleanMetadata(m,duration=0){
  const title=String(m?.title||'はりけーんradio ミーティング').replace(/[\r\n]+/g,' ').replace(/\s+/g,' ').trim().slice(0,40)||'はりけーんradio ミーティング',theme=String(m?.theme||'今回のトーク').replace(/[\r\n]+/g,' ').replace(/\s+/g,' ').trim().slice(0,50)||'今回のトーク';
  const topics=(Array.isArray(m?.topics)?m.topics:[]).slice(0,20).map((x,i)=>({start:Math.max(0,Math.min(Number(duration)||86400,Number(x?.start)||0)),label:String(x?.label||`トーク ${i+1}`).replace(/[\r\n]+/g,' ').replace(/\s+/g,' ').trim().slice(0,32)||`トーク ${i+1}`})).sort((a,b)=>a.start-b.start);if(!topics.length)topics.push({start:0,label:theme});if(topics[0].start>1)topics.unshift({start:0,label:theme});return{title,theme,topics,model:String(m?.model||'edited').slice(0,80),fallback:!!m?.fallback,editedAt:new Date().toISOString()};
}
async function transcriptSave(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});if(!Array.isArray(b.segments)||b.segments.length>20000)return res.status(400).json({error:'invalid_segments'});
  try{const sb=await getOrCreate(j,false);if(await pipelineAlive(sb))return processingConflict(res);const old=JSON.parse(await stdout(sb,'cat',[TRANSCRIPT])),segments=b.segments.map(cleanSegment).filter(x=>x.text).sort((a,z)=>a.start-z.start||a.end-z.end),tr={...old,segments,editedAt:new Date().toISOString(),editedBy:'review-ui'},metadata=cleanMetadata(b.metadata,Number(old.duration||0));if(!segments.length)throw new Error('TRANSCRIPT_EMPTY');await sb.writeFiles([{path:TRANSCRIPT,content:Buffer.from(JSON.stringify(tr,null,2))},{path:METADATA,content:Buffer.from(JSON.stringify(metadata,null,2))},{path:STATUS,content:Buffer.from(JSON.stringify({jobId:j,stage:'transcript_review',phase:'修正内容を保存しました',progress:55,segments:segments.length,duration:Number(tr.duration||0),updatedAt:new Date().toISOString()}))}]);await sb.runCommand('bash',['-lc',`rm -f ${APPROVAL} ${FINAL}; rm -rf ${BASE}/renders`]);return res.status(200).json({ok:true,segments:segments.length,metadata:true})}
  catch(e){return res.status(500).json({error:'transcript_save_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function renderStart(req,res){
  const b=await requestBody(req,res);if(!b)return;const j=jobAuth(b);if(!j)return res.status(401).json({error:'unauthorized'});
  try{const sb=await getOrCreate(j,false),tr=JSON.parse(await stdout(sb,'cat',[TRANSCRIPT]));if(!Array.isArray(tr.segments)||!tr.segments.length)return res.status(409).json({error:'transcript_empty'});const approval={jobId:j,approvedAt:new Date().toISOString(),segments:tr.segments.length,transcriptHash:hash(JSON.stringify(tr.segments))};await sb.writeFiles([{path:APPROVAL,content:Buffer.from(JSON.stringify(approval,null,2))},{path:STATUS,content:Buffer.from(JSON.stringify({jobId:j,stage:'render_queued',phase:'確認内容から動画作成を準備中',progress:56,segments:tr.segments.length,updatedAt:new Date().toISOString()}))}]);await sb.runCommand('bash',['-lc',`rm -f ${FINAL}; rm -rf ${BASE}/renders`]);await prep(sb,j,token(j),origin(req));await runPipeline(sb);return res.status(202).json({ok:true,renderStarted:true})}
  catch(e){return res.status(500).json({error:'render_start_failed',detail:String(e?.message||e).slice(0,700)})}
}
async function createMetadata(segments,duration){
  const rows=(Array.isArray(segments)?segments:[]).slice(0,20000).map(x=>`[${Math.max(0,Number(x.start)||0).toFixed(1)}秒] ${String(x.speaker||'unknown')}: ${String(x.text||'').replace(/[\r\n]+/g,' ').slice(0,500)}`).join('\n').slice(0,180000);if(!rows.trim())throw new Error('METADATA_TRANSCRIPT_EMPTY');
  const schema={type:'object',properties:{title:{type:'string'},theme:{type:'string'},topics:{type:'array',items:{type:'object',properties:{start:{type:'number'},label:{type:'string'}},required:['start','label'],additionalProperties:false}}},required:['title','theme','topics'],additionalProperties:false};
  const payload={model:'gpt-5.6-luna',messages:[{role:'system',content:'あなたは日本語ラジオ番組の編集者です。文字起こしだけを根拠に、自然で簡潔な番組タイトル、全体テーマ、話題の切り替わりを作成してください。タイトルは28文字以内、テーマは36文字以内、各話題名は24文字以内、話題は1〜8件。話題のstartは文字起こしにある秒数を使い昇順、最初は0秒にしてください。内容を捏造せず、判断できない場合は無難な表現にしてください。'},{role:'user',content:`収録時間: ${Number(duration||0).toFixed(1)}秒\n\n${rows}`}],reasoning_effort:'none',store:false,max_completion_tokens:1800,response_format:{type:'json_schema',json_schema:{name:'radio_metadata',strict:true,schema}}};
  const c=new AbortController(),tm=setTimeout(()=>c.abort(),120000);try{const o=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'content-type':'application/json'},body:JSON.stringify(payload),signal:c.signal}),text=await o.text();if(!o.ok)throw new Error(`OpenAI ${o.status}: ${text.slice(0,900)}`);const data=JSON.parse(text),content=data.choices?.[0]?.message?.content;if(!content)throw new Error('METADATA_OUTPUT_EMPTY');return cleanMetadata({...JSON.parse(content),model:'gpt-5.6-luna'},duration)}finally{clearTimeout(tm)}
}
async function generateMetadata(req,res){
  const j=String(req.headers['x-hrai-job-id']||''),auth=String(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(!valid(j)||auth!==token(j))return res.status(401).json({error:'unauthorized'});const b=await requestBody(req,res);if(!b)return;try{return res.status(200).json(await createMetadata(b.segments,Number(b.duration||0)))}catch(e){console.error('metadata generation failed',e);return res.status(502).json({error:'metadata_generation_failed',detail:String(e?.message||e).slice(0,1000)})}
}
async function smoke(req,res){
  if(process.env.VERCEL_ENV!=='preview'&&!ok(req.query?.access))return res.status(401).json({error:'owner_access_required'});
  let sb,j=`job_${crypto.randomBytes(12).toString('hex')}`;
  try{
    sb=await mk(`hrai-smoke-${j.slice(4)}`,false,120000);await prep(sb,j,token(j),origin(req));
    const marker=crypto.randomBytes(12).toString('hex'),sample={version:3,segments:[{id:'smoke',start:0,end:1,text:marker,speaker:'speaker_1',chunk:0}]};
    await sb.writeFiles([{path:`${BASE}/bridge-smoke.txt`,content:Buffer.from(marker)},{path:TRANSCRIPT,content:Buffer.from(JSON.stringify(sample))}]);
    const read=(await stdout(sb,'cat',[`${BASE}/bridge-smoke.txt`])).trim(),roundtrip=JSON.parse(await stdout(sb,'cat',[TRANSCRIPT]));if(read!==marker||roundtrip.segments?.[0]?.text!==marker)throw new Error('BRIDGE_ROUNDTRIP_FAILED');
    await sb.runCommand('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=660:duration=1','-c:a','aac','-f','ipod','-y',ED]);
    const edDuration=Number((await stdout(sb,'ffprobe',['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',ED])).trim());if(!Number.isFinite(edDuration)||edDuration<.9)throw new Error('ED_AUDIO_PROBE_FAILED');
    const mastered=`${BASE}/auto-finish-smoke.m4a`,masterFilter='[0:a]highpass=f=70,lowpass=f=15000,acompressor=threshold=0.125:ratio=2.4:attack=15:release=180:makeup=1.35,alimiter=limit=0.94,asplit=2[voice][ducksrc];[1:a]lowpass=f=1800,aecho=0.8:0.65:240|480:0.16|0.10,volume=0.65[bed];[bed][ducksrc]sidechaincompress=threshold=0.025:ratio=10:attack=20:release=700[ducked];[voice][ducked]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95,aresample=48000[aout]';await sb.runCommand('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=2','-f','lavfi','-i','aevalsrc=0.025*(sin(2*PI*110*t)+0.55*sin(2*PI*164.81*t)+0.35*sin(2*PI*220*t)):s=48000:d=2','-filter_complex',masterFilter,'-map','[aout]','-c:a','aac','-ar','48000','-ac','2','-y',mastered]);const masteredMeta=JSON.parse(await stdout(sb,'ffprobe',['-v','error','-select_streams','a:0','-show_entries','stream=codec_name,sample_rate,channels','-of','json',mastered])),masteredAudio=masteredMeta.streams?.[0];if(masteredAudio?.codec_name!=='aac'||masteredAudio?.sample_rate!=='48000'||masteredAudio?.channels!==2)throw new Error('AUTO_FINISH_AUDIO_PROBE_FAILED');
    await sb.runCommand('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=0x45d69a:s=64x64','-frames:v','1','-y',AVATAR_R]);
    const avatar=JSON.parse(await stdout(sb,'ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=width,height','-of','json',AVATAR_R]));if(avatar.streams?.[0]?.width!==64)throw new Error('AVATAR_PROBE_FAILED');
    const thumb=`${BASE}/thumbnail-smoke.jpg`;await sb.runCommand('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=0x111d45:s=1280x720','-frames:v','1','-q:v','3','-y',thumb]);const thumbMeta=JSON.parse(await stdout(sb,'ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=width,height','-of','json',thumb]));if(thumbMeta.streams?.[0]?.width!==1280||thumbMeta.streams?.[0]?.height!==720)throw new Error('THUMBNAIL_PROBE_FAILED');
    const jp=`${BASE}/japanese-font-smoke.jpg`;await sb.runCommand('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=0x111d45:s=640x180','-vf',"drawtext=font='Noto Sans CJK JP':text='日本語表示確認':fontcolor=white:fontsize=42:x=30:y=55",'-frames:v','1','-q:v','3','-y',jp]);const jpBytes=Number((await stdout(sb,'stat',['-c','%s',jp])).trim());if(jpBytes<3000)throw new Error('JAPANESE_DYNAMIC_FONT_PROBE_FAILED');
    const smp=`${BASE}/export-smoke.mp3`,swv=`${BASE}/export-smoke.wav`,stx=`${BASE}/export-smoke.txt`;await sb.runCommand('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=1','-c:a','libmp3lame','-b:a','192k','-y',smp]);await sb.runCommand('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=1','-c:a','pcm_s16le','-ar','48000','-ac','2','-y',swv]);await sb.writeFiles([{path:stx,content:Buffer.from('\uFEFF[00:00:00 - 00:00:01] RYOKU：書き出し確認\n')}]);const mp3=JSON.parse(await stdout(sb,'ffprobe',['-v','error','-select_streams','a:0','-show_entries','stream=codec_name','-of','json',smp])),wav=JSON.parse(await stdout(sb,'ffprobe',['-v','error','-select_streams','a:0','-show_entries','stream=codec_name,sample_rate,channels','-of','json',swv])),txtBytes=Number((await stdout(sb,'stat',['-c','%s',stx])).trim());if(mp3.streams?.[0]?.codec_name!=='mp3'||wav.streams?.[0]?.codec_name!=='pcm_s16le'||wav.streams?.[0]?.sample_rate!=='48000'||wav.streams?.[0]?.channels!==2||txtBytes<20)throw new Error('MULTI_EXPORT_PROBE_FAILED');
    const metadata=await createMetadata([{start:0,speaker:'speaker_1',text:'今日は新しいラジオ動画の自動編集について話します。'}],30);if(!metadata.title||!metadata.topics?.length)throw new Error('METADATA_GENERATION_FAILED');
    return res.status(200).json({ok:true,sdkBridge:true,transcriptRoundtrip:true,reviewUiReady:true,reloadRecovery:true,statusTimeoutRecovery:true,noKillOnReconnect:true,renderDirectoryRaceGuard:true,reconnectSkipsMutations:true,corruptPartRecovery:true,mediaPacketValidation:true,atomicRenderParts:true,ffmpegSignalRecovery:true,ffmpegAutoResumeLimit:3,singleThreadRendering:true,autoFinish:true,voiceMastering:true,smartCaptionCues:true,harmonicBgm:true,finalMediaQA:true,autoFinishAudioProbe:true,japaneseDynamicTextFont:true,bustUpDefault:true,proFullBodyOption:true,edAudioProbe:true,radioVisualsReady:true,cinematicSimpleVisuals:true,broadcastLayout:true,speakerLowerThird:true,animatedStudioBackground:true,realAudioWaveform:true,topicTransitions:true,musicReactiveEnding:true,episodeProgress:true,automaticOp:true,automaticBgm:true,speakerCards:true,avatarPipelineReady:true,castSelectionReady:true,guestPresetCount:10,chibiGuestStyle:true,castProfilesReady:true,thumbnailGenerationReady:true,thumbnailCount:3,multiExportReady:true,exportKinds:['mp4','mp3','wav','transcript'],metadataGenerationReady:true,structuredOutput:true,metadataModel:'gpt-5.6-luna',publicPortRequired:false,environment:process.env.VERCEL_ENV})
  }
  catch(e){console.error('smoke failed',e);return res.status(500).json({ok:false,detail:String(e?.message||e)})}finally{if(sb)try{await sb.stop()}catch{}}
}
async function transcribe(req,res){const j=String(req.headers['x-hrai-job-id']||''),auth=String(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(!valid(j)||auth!==token(j))return res.status(401).json({error:'unauthorized'});let b;try{b=await body(req)}catch{return res.status(400).json({error:'invalid_json'})}const a=Buffer.from(String(b.audioBase64||''),'base64');if(a.length<512||a.length>4000000)return res.status(400).json({error:'invalid_audio_size'});const refs=(Array.isArray(b.refs)?b.refs:[]).slice(0,4).filter(x=>x?.name&&x?.dataUrl&&x.dataUrl.length<4000000);const transient=new Set([408,409,425,429,500,502,503,504]);let last='';for(let n=0;n<4;n++){try{const f=new FormData();f.append('file',new Blob([a],{type:'audio/mpeg'}),String(b.filename||'chunk.mp3'));f.append('model','gpt-4o-transcribe-diarize');f.append('response_format','diarized_json');f.append('chunking_strategy','auto');f.append('language','ja');for(const x of refs){f.append('known_speaker_names[]',String(x.name));f.append('known_speaker_references[]',String(x.dataUrl))}const c=new AbortController(),tm=setTimeout(()=>c.abort(),240000),o=await fetch('https://api.openai.com/v1/audio/transcriptions',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},body:f,signal:c.signal});clearTimeout(tm);const text=await o.text();if(o.ok){res.statusCode=200;res.setHeader('content-type','application/json; charset=utf-8');return res.end(text)}last=`OpenAI ${o.status}: ${text.slice(0,1000)}`;if(!transient.has(o.status))break}catch(e){last=String(e?.message||e)}if(n<3)await new Promise(r=>setTimeout(r,700*(2**n)))}return res.status(502).json({error:'transcription_failed',detail:last.slice(0,1200)})}
async function ai(res){let configured=!!process.env.OPENAI_API_KEY,reachable=false;if(configured)try{reachable=(await fetch('https://api.openai.com/v1/models/gpt-4o-transcribe-diarize',{headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`}})).ok}catch{}return res.status(200).json({configured,reachable,model:'gpt-4o-transcribe-diarize'})}

export default async function h(req,res){
  res.setHeader('cache-control','no-store');const r=String(req.query?.route||'');
  if(r==='health')return res.status(200).json({ok:true,version:'4.4.2-rc14.2-bust-up-default'});
  if(r==='openai-status')return ai(res);
  if(r==='worker-status')return res.status(200).json({ready:true,ffmpeg:true,japaneseFont:true,resumable:true,transport:'vercel-api-bridge'});
  if(r==='start-job')return req.method==='POST'?start(req,res):res.status(405).end();
  if(r==='start-job-smoke')return smoke(req,res);
  if(r==='source-info')return req.method==='POST'?sourceInfo(req,res):res.status(405).end();
  if(r==='job-status')return req.method==='POST'?status(req,res):res.status(405).end();
  if(r==='resume-job')return req.method==='POST'?resume(req,res):res.status(405).end();
  if(r==='upload-init')return req.method==='POST'?uploadInit(req,res):res.status(405).end();
  if(r==='upload-chunk')return req.method==='POST'?uploadChunk(req,res):res.status(405).end();
  if(r==='upload-complete')return req.method==='POST'?uploadComplete(req,res):res.status(405).end();
  if(r==='ed-upload-init')return req.method==='POST'?edUploadInit(req,res):res.status(405).end();
  if(r==='ed-upload-chunk')return req.method==='POST'?edUploadChunk(req,res):res.status(405).end();
  if(r==='ed-upload-complete')return req.method==='POST'?edUploadComplete(req,res):res.status(405).end();
  if(r==='ed-clear')return req.method==='POST'?edClear(req,res):res.status(405).end();
  if(r==='avatar-upload-init')return req.method==='POST'?avatarUploadInit(req,res):res.status(405).end();
  if(r==='avatar-upload-chunk')return req.method==='POST'?avatarUploadChunk(req,res):res.status(405).end();
  if(r==='avatar-upload-complete')return req.method==='POST'?avatarUploadComplete(req,res):res.status(405).end();
  if(r==='avatar-clear')return req.method==='POST'?avatarClear(req,res):res.status(405).end();
  if(r==='cast-save')return req.method==='POST'?castSave(req,res):res.status(405).end();
  if(r==='artifact-info')return req.method==='POST'?artifactInfo(req,res):res.status(405).end();
  if(r==='artifact-chunk')return req.method==='POST'?artifactChunk(req,res):res.status(405).end();
  if(r==='export-info')return req.method==='POST'?exportInfo(req,res):res.status(405).end();
  if(r==='export-chunk')return req.method==='POST'?exportChunk(req,res):res.status(405).end();
  if(r==='thumbnail-get')return req.method==='POST'?thumbnailGet(req,res):res.status(405).end();
  if(r==='transcript-get')return req.method==='POST'?transcriptGet(req,res):res.status(405).end();
  if(r==='transcript-save')return req.method==='POST'?transcriptSave(req,res):res.status(405).end();
  if(r==='render-start')return req.method==='POST'?renderStart(req,res):res.status(405).end();
  if(r==='transcribe-chunk')return req.method==='POST'?transcribe(req,res):res.status(405).end();
  if(r==='generate-metadata')return req.method==='POST'?generateMetadata(req,res):res.status(405).end();
  return res.status(404).json({error:'not_found'});
}
